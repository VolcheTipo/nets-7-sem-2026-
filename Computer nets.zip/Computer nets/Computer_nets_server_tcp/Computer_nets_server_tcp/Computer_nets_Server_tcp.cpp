﻿#undef UNICODE  // чтобы использовать ANSI-строки отключаем UNICODE ради совместимости с socket API. Это упрощает работу с WinSock

#define WIN32_LEAN_AND_MEAN

#include <windows.h>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <stdlib.h>
#include <stdio.h>
#include <thread>
#include <iostream>

using namespace std;

#pragma comment (lib, "Ws2_32.lib")

#define DEFAULT_BUFLEN 512
#define DEFAULT_PORT "27015"

//Важные моменты: 
//1) iResult - сокет, который мы создаем, привязываем к адресу и порту и "слушаем" (т.е. создается tcp-сервер)
//2) Клиенты принимаются и обрабатываются в отдельных потоках
//3) Слушаем порт 27015; длина буфера 512 байт - сколько данных можно получить за раз (указано выше)
//4) IPv4

void function(SOCKET ClientSocket) {
    int iResult;
    int iSendResult;
    char recvbuf[DEFAULT_BUFLEN];
    int recvbuflen = DEFAULT_BUFLEN;

    do {    //данные от клиента обрабатываются в цикле
        iResult = recv(ClientSocket, recvbuf, recvbuflen, 0);
        if (iResult > 0) {
            printf("Bytes received: %d\n", iResult);
            Sleep(20000);  //долго обрабатывается (задержка 20 сек)

            iSendResult = send(ClientSocket, recvbuf, iResult, 0); //эхо-ответ
            if (iSendResult == SOCKET_ERROR) {
                printf("send failed with error: %d\n", WSAGetLastError());
                return;  
            }
            printf("Bytes sent: %d\n", iSendResult);
        }
        else if (iResult == 0) {
            printf("Connection closing...\n");  // клиент корректно закрывает соединение 
        }
        else {
            if (WSAGetLastError() == WSAEWOULDBLOCK) { //проверка на то, не блокирующий ли режим 
                printf("do something ...\n"); 
                Sleep(1000); 
            }
            else {
                printf("recv failed with error: %d\n", WSAGetLastError());
                return;  
            }
        }
    } while (iResult != 0);  

    
}

int __cdecl main(void)
{
    setlocale(LC_ALL, "Russian");  
    
    WSADATA wsaData;
    int iResult;

    SOCKET ListenSocket = INVALID_SOCKET;   
    SOCKET ClientSocket = INVALID_SOCKET;   

    struct addrinfo* result = NULL;
    struct addrinfo hints;

    int iSendResult;
    char recvbuf[DEFAULT_BUFLEN];
    int recvbuflen = DEFAULT_BUFLEN;

    iResult = WSAStartup(MAKEWORD(2, 2), &wsaData); 
    if (iResult != 0) {
        printf("WSAStartup failed with error: %d\n", iResult);
        return 1;
    }

    ZeroMemory(&hints, sizeof(hints));
    hints.ai_family = AF_INET;        
    hints.ai_socktype = SOCK_STREAM;  
    hints.ai_protocol = IPPROTO_TCP; 
    hints.ai_flags = AI_PASSIVE;      
 
    iResult = getaddrinfo(NULL, DEFAULT_PORT, &hints, &result); 
    if (iResult != 0) {
        printf("getaddrinfo failed with error: %d\n", iResult);
        WSACleanup();
        return 1;
    }
    //сервер слушает входящие подключения; используется максимально допустимая очередь подключений
    ListenSocket = socket(result->ai_family, result->ai_socktype, result->ai_protocol); 
    if (ListenSocket == INVALID_SOCKET) {
        printf("socket failed with error: %ld\n", WSAGetLastError());
        freeaddrinfo(result);  //проверка на ошибку. освобождение памяти, удаляет addrinfo со всеми связанными узлами и буферами, чтобы не было утечек памяти
        WSACleanup();
        return 1;
    }

    iResult = bind(ListenSocket, result->ai_addr, (int)result->ai_addrlen); //привязка сокета к адресу и порту
    if (iResult == SOCKET_ERROR) {
        printf("bind failed with error: %d\n", WSAGetLastError());
        freeaddrinfo(result);  
        closesocket(ListenSocket);  
        WSACleanup();
        return 1;
    }

    freeaddrinfo(result);  

    iResult = listen(ListenSocket, SOMAXCONN); //Перевод сокета в режим прослушивания
    if (iResult == SOCKET_ERROR) {
        printf("listen failed with error: %d\n", WSAGetLastError());
        closesocket(ListenSocket);
        WSACleanup();
        return 1;
    }

    //коргда клиент подключается - создаем клиент. сокет
    while (true) { //ОСНОВНОЙ цикл сервера
        u_long mode = 1;  //1 = неблокирующий режим, 0 = блокирующий; в неблок. режиме recv не зависают и сервер продолжает работу

        ClientSocket = accept(ListenSocket, NULL, NULL);
        if (ClientSocket == INVALID_SOCKET) {
            printf("accept failed with error: %d\n", WSAGetLastError());
            closesocket(ListenSocket);
            WSACleanup();
            return 1;  
        }
        ioctlsocket(ClientSocket, FIONBIO, &mode); // Перевод клиентского сокета в неблокирующий режим
        thread(function, ClientSocket).detach(); //создание потока для каждого клиента, detach() делает поток независимым (освобожает от управляющей сущности)
    }
    return 0;
}


//recv - читает/принимает данные из сетевого сокета в буфер комп-ра
//detach - отсоединение потока; сервер не ждет завершение клиентского потока, потоки автономны
//bind - привязка сокета к адресу и порту

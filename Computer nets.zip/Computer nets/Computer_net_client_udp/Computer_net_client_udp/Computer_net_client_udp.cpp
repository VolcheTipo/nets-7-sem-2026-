﻿#define WIN32_LEAN_AND_MEAN

#include <windows.h>        
#include <winsock2.h>       
#include <ws2tcpip.h>       
#include <stdio.h>          
#include <iostream>         
#include <string>           
#include <thread> 

using namespace std;        

#pragma comment (lib, "Ws2_32.lib")

#define BUFFER_SIZE 512        
#define PORT "8888"            
#define BROADCAST_PORT "8889"  
#define CLIENT_BROADCAST_PORT 8890  

void SimpleTcpClient(const string& serverIP, int messageCount) { //TCP 
    WSADATA wsaData;           
    SOCKET clientSocket;       
    sockaddr_in serverAddr;    
    char buffer[BUFFER_SIZE];  

    WSAStartup(MAKEWORD(2, 2), &wsaData);

    clientSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

    serverAddr.sin_family = AF_INET;                
    serverAddr.sin_port = htons(atoi(PORT));         
    inet_pton(AF_INET, serverIP.c_str(), &serverAddr.sin_addr); // str addr в bin 

    connect(clientSocket, (sockaddr*)&serverAddr, sizeof(serverAddr));

    printf("TCP Client: Connected to %s:%s\n", serverIP.c_str(), PORT);
    printf("Enter %d messages (type 'quit' to exit early):\n\n", messageCount);

    for (int i = 1; i <= messageCount; i++) {
        string userMessage;
        cout << "Message " << i << "/" << messageCount << ": ";
        getline(cin, userMessage);

        if (userMessage == "quit") {
            printf("Early exit requested\n");
            break;
        }

        if (userMessage.empty()) {
            printf("Empty message, using default\n");
            userMessage = "TCP Message " + to_string(i);
        }

        strncpy_s(buffer, userMessage.c_str(), BUFFER_SIZE - 1);
        buffer[BUFFER_SIZE - 1] = '\0';  

        int sent = send(clientSocket, buffer, strlen(buffer), 0);
        if (sent == SOCKET_ERROR) {
            printf("Send failed: %d\n", WSAGetLastError());
            break;
        }

        int bytes = recv(clientSocket, buffer, BUFFER_SIZE, 0); //прием эхо-ответа
        if (bytes > 0) {
            buffer[bytes] = '\0';
            printf("Echo: %s\n\n", buffer);
        }
        else if (bytes == 0) {
            printf("Server closed connection\n");
            break;
        }
        else {
            printf("Receive error: %d\n", WSAGetLastError());
            break;
        }
    }
    closesocket(clientSocket);  
    WSACleanup();               

    printf("TCP Client finished\n");
}


void SimpleUdpClient(const string& serverIP, int messageCount) {   //UDP
    WSADATA wsaData;           
    SOCKET udpSocket;          
    sockaddr_in serverAddr;    
    char buffer[BUFFER_SIZE];  

    WSAStartup(MAKEWORD(2, 2), &wsaData);

    udpSocket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);

    serverAddr.sin_family = AF_INET;                 
    serverAddr.sin_port = htons(atoi(PORT));         
    inet_pton(AF_INET, serverIP.c_str(), &serverAddr.sin_addr);

    printf("UDP Client: Target server %s:%s\n", serverIP.c_str(), PORT);
    printf("Sending %d messages...\n\n", messageCount);


    for (int i = 1; i <= messageCount; i++) {
        sockaddr_in fromAddr;
        int fromLen = sizeof(fromAddr);

        string userMessage;
        cout << "Message " << i << "/" << messageCount << ": ";
        getline(cin, userMessage);

        if (userMessage == "quit") {  // проверка на quit 
            printf("Early exit requested\n");
            break;
        }

        if (userMessage.empty()) {  // проверка на empty 
            printf("Empty message, using default\n");
            userMessage = "UDP Message " + to_string(i);
        }

        strncpy_s(buffer, userMessage.c_str(), BUFFER_SIZE - 1);
        buffer[BUFFER_SIZE - 1] = '\0';  

        int sent = sendto(udpSocket, buffer, strlen(buffer), 0,   //sent
            (sockaddr*)&serverAddr, sizeof(serverAddr));
        if (sent == SOCKET_ERROR) {
            printf("Send failed: %d\n", WSAGetLastError());
            break;
        }

        int bytes = recvfrom(udpSocket, buffer, BUFFER_SIZE, 0,  //эхо-ответ
            (sockaddr*)&fromAddr, &fromLen);
        if (bytes > 0) {
            buffer[bytes] = '\0';
            printf("Echo: %s\n\n", buffer);
        }
        else {
            printf("No response or error\n\n");
        }

        Sleep(1000); 
    }
    closesocket(udpSocket);  
    WSACleanup();            

    printf("UDP Client finished\n");
}


void SimpleBroadcastClient() {   //BROADCAST
    WSADATA wsaData;
    SOCKET broadcastSocket;
    sockaddr_in broadcastAddr, clientAddr;
    char buffer[BUFFER_SIZE];

    WSAStartup(MAKEWORD(2, 2), &wsaData);
    broadcastSocket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);

    int reuse = 1;
    setsockopt(broadcastSocket, SOL_SOCKET, SO_REUSEADDR, (char*)&reuse, sizeof(reuse));

    clientAddr.sin_family = AF_INET;
    clientAddr.sin_port = htons(8890); // клиенты слушают на 8890
    clientAddr.sin_addr.s_addr = INADDR_ANY;
    if (bind(broadcastSocket, (sockaddr*)&clientAddr, sizeof(clientAddr)) == SOCKET_ERROR) {
        printf("Bind failed: %d\n", WSAGetLastError());
        closesocket(broadcastSocket);
        WSACleanup();
        return;
    }

    int broadcast = 1;
    setsockopt(broadcastSocket, SOL_SOCKET, SO_BROADCAST, (char*)&broadcast, sizeof(broadcast)); // разрешение broadcast
 
    //int timeout = 2000; 
    //setsockopt(broadcastSocket, SOL_SOCKET, SO_RCVTIMEO, (char*)&timeout, sizeof(timeout));

    broadcastAddr.sin_family = AF_INET;
    broadcastAddr.sin_port = htons(atoi(BROADCAST_PORT)); // 8889 - сервер слушает
    inet_pton(AF_INET, "127.255.255.255", &broadcastAddr.sin_addr);

    printf("=== BROADCAST CLIENT ===\n");
    printf("Client ID: %d\n", GetCurrentProcessId());
    printf("Listening on port: 8890\n");
    printf("Sending to: 255.255.255.255:8889\n");
    printf("Type 'quit' to exit\n\n");

    bool printingMessage = false;

    thread receiver([&]() {
        char buf[BUFFER_SIZE];
        while (true) {
            sockaddr_in from;
            int fromLen = sizeof(from);
            int bytes = recvfrom(broadcastSocket, buf, BUFFER_SIZE, 0,
                (sockaddr*)&from, &fromLen);

            if (bytes > 0) {
                buf[bytes] = '\0';
                char fromIP[16];
                inet_ntop(AF_INET, &from.sin_addr, fromIP, 16);
                int fromPort = ntohs(from.sin_port);

                char myId[20];
                sprintf_s(myId, "Client%d", GetCurrentProcessId() % 1000);

                if (strstr(buf, myId) == NULL) {
                    if (!printingMessage) {
                        printingMessage = true;
                        printf("\n [FROM %s:%d] %s\n", fromIP, fromPort, buf);
                        printf("Client: ");
                        cout.flush();
                        printingMessage = false;
                    }
                }
            }
        }
        });
    receiver.detach();

    int msgCount = 0;
    while (true) { 
        string message;
        cout << " Client: ";
        getline(cin, message);

        if (message == "quit") break;
        if (message.empty()) continue;

        msgCount++;
        char fullMsg[BUFFER_SIZE];
        sprintf_s(fullMsg, "[Client%d-M%d] %s",
            GetCurrentProcessId() % 1000, msgCount, message.c_str());

        int sent = sendto(broadcastSocket, fullMsg, strlen(fullMsg), 0,
            (sockaddr*)&broadcastAddr, sizeof(broadcastAddr));

        if (sent == SOCKET_ERROR) {
            printf("Send error: %d\n", WSAGetLastError());
        }
        else {
            //printf("Sent: %s\n", fullMsg);
        }
    }

    closesocket(broadcastSocket);
    WSACleanup();
    printf("\nClient finished\n");
}


int main() {
    printf("=== SIMPLE ECHO CLIENT ===\n\n");

    printf("Select mode:\n");
    printf("1. TCP Client\n");
    printf("2. UDP Client\n");
    printf("3. Broadcast Client\n");
    printf("Choice: ");

    int choice;
    cin >> choice;       
    cin.ignore();        

    if (choice == 1 || choice == 2) {
        
        string serverIP = "";
        int messageCount;

        //cout << "Server IP (default: 127.0.0.1): ";
        //getline(cin, serverIP);

        if (serverIP.empty()) {
            serverIP = "127.0.0.1";  
        }

        cout << "Number of messages: ";
        cin >> messageCount;
        cin.ignore();

        if (messageCount <= 0) messageCount = 3;  

        if (choice == 1) {
            SimpleTcpClient(serverIP, messageCount);
        }
        else {
            SimpleUdpClient(serverIP, messageCount);
        }
    }
    else if (choice == 3) {
        SimpleBroadcastClient();
    }
    else {
        printf("Invalid choice\n");
    }

    printf("\nPress Enter to exit...");
    getchar();

    return 0;
}
﻿#define _WINSOCK_DEPRECATED_NO_WARNINGS  
#define WIN32_LEAN_AND_MEAN

#include <windows.h>        
#include <winsock2.h>       
#include <ws2tcpip.h>       
#include <stdio.h>          
#include <string>           
#include <thread>           

using namespace std;        

#pragma comment (lib, "Ws2_32.lib")
#define BUFFER_SIZE 512        
#define TCP_PORT "8888"        
#define UDP_PORT "8888"        
#define BROADCAST_PORT "8889" 
#define CLIENT_LISTEN_PORT 8890 

void HandleTcpClient(SOCKET clientSocket) { //для каждого потока отдельный вызов это функции TCP
    char buffer[BUFFER_SIZE];  
    int bytesReceived;          

    printf("[TCP] Client connected\n");

    while (true) {
        bytesReceived = recv(clientSocket, buffer, BUFFER_SIZE, 0);

        if (bytesReceived > 0) {
            buffer[bytesReceived] = '\0';  
            printf("[TCP] Received: %s\n", buffer);
            send(clientSocket, buffer, bytesReceived, 0); //эхо ответ
            printf("[TCP] Echo sent\n");
        }
        else if (bytesReceived == 0) {
            printf("[TCP] Client disconnected\n");
            break;  
        }
        else {
            printf("[TCP] Error\n");
            break;  
        }
    }
    closesocket(clientSocket);
}


void HandleUdp(SOCKET udpSocket) { //для каждого потока отдельный вызов это функции UDP
    char buffer[BUFFER_SIZE];      
    sockaddr_in clientAddr;        
    int addrSize = sizeof(clientAddr);  

    printf("[UDP] Ready on port %s\n", UDP_PORT);

    while (true) {
        int bytesReceived = recvfrom(udpSocket, buffer, BUFFER_SIZE, 0,
            (sockaddr*)&clientAddr, &addrSize);
        if (bytesReceived > 0) {
            buffer[bytesReceived] = '\0';
            char clientIP[16];
            inet_ntop(AF_INET, &clientAddr.sin_addr, clientIP, 16);

            printf("[UDP] From %s: %s\n", clientIP, buffer);

            sendto(udpSocket, buffer, bytesReceived, 0, //эхо ответ
                (sockaddr*)&clientAddr, addrSize);
            printf("[UDP] Echo sent\n");
        }

    }
}


void HandleBroadcast(SOCKET broadcastSocket) {
    char buffer[BUFFER_SIZE];
    sockaddr_in clientAddr;
    int addrSize = sizeof(clientAddr);

    printf("[BROADCAST] Listening on port %s\n", BROADCAST_PORT);
    printf("[BROADCAST] Broadcasting to 255.255.255.255:8890\n");

    while (true) {
        int bytesReceived = recvfrom(broadcastSocket, buffer, BUFFER_SIZE, 0,
            (sockaddr*)&clientAddr, &addrSize);

        if (bytesReceived > 0) {
            buffer[bytesReceived] = '\0';

            char clientIP[16];
            inet_ntop(AF_INET, &clientAddr.sin_addr, clientIP, 16);

            printf("[BROADCAST] From %s: %s\n", clientIP, buffer);

            sockaddr_in broadcastAddr;
            broadcastAddr.sin_family = AF_INET;
            broadcastAddr.sin_port = htons(8890);
            broadcastAddr.sin_addr.s_addr = INADDR_BROADCAST; //255.255.255.255

            int sent = sendto(broadcastSocket, buffer, bytesReceived, 0,
                (sockaddr*)&broadcastAddr, sizeof(broadcastAddr));

            if (sent == SOCKET_ERROR) {
                printf("[BROADCAST] Send error: %d\n", WSAGetLastError());
            }
            else {
                printf("[BROADCAST] Broadcast sent\n");
            }
        }
    }
}
    

int main() {
    WSADATA wsaData;  

    printf("=== SIMPLE ECHO SERVER ===\n");
    printf("TCP Port: %s\n", TCP_PORT);
    printf("UDP Port: %s\n", UDP_PORT);
    printf("Broadcast Port: %s\n", BROADCAST_PORT);
    printf("==========================\n\n");

    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        printf("WSAStartup failed\n");
        return 1;  
    }

    SOCKET tcpSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (tcpSocket == INVALID_SOCKET) {
        printf("TCP socket error\n");
        WSACleanup();  
        return 1;      
    }

    sockaddr_in tcpAddr;
    tcpAddr.sin_family = AF_INET;               
    tcpAddr.sin_port = htons(atoi(TCP_PORT));   
    tcpAddr.sin_addr.s_addr = INADDR_ANY;       
    
    if (bind(tcpSocket, (sockaddr*)&tcpAddr, sizeof(tcpAddr)) == SOCKET_ERROR) {
        printf("TCP bind error\n");
        closesocket(tcpSocket);  
        WSACleanup();            
        return 1;                
    }

    listen(tcpSocket, SOMAXCONN);
    printf("[INFO] TCP server ready\n");

    SOCKET udpSocket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (udpSocket == INVALID_SOCKET) {
        printf("UDP socket error\n");
        closesocket(tcpSocket); 
        WSACleanup();           
        return 1;                
    }

    sockaddr_in udpAddr;
    udpAddr.sin_family = AF_INET;               
    udpAddr.sin_port = htons(atoi(UDP_PORT));   
    udpAddr.sin_addr.s_addr = INADDR_ANY;       

    if (bind(udpSocket, (sockaddr*)&udpAddr, sizeof(udpAddr)) == SOCKET_ERROR) {
        printf("UDP bind error\n");
        closesocket(tcpSocket);  
        closesocket(udpSocket);  
        WSACleanup();            
        return 1;                
    }

    SOCKET broadcastSocket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (broadcastSocket == INVALID_SOCKET) {
        printf("Broadcast socket error\n");
        closesocket(tcpSocket);  
        closesocket(udpSocket);  
        WSACleanup();            
        return 1;                
    }

    int broadcast = 1;
    setsockopt(broadcastSocket, SOL_SOCKET, SO_BROADCAST,
        (char*)&broadcast, sizeof(broadcast));

    sockaddr_in broadcastAddr;
    broadcastAddr.sin_family = AF_INET;                    
    broadcastAddr.sin_port = htons(atoi(BROADCAST_PORT));  
    broadcastAddr.sin_addr.s_addr = INADDR_ANY;            

    if (bind(broadcastSocket, (sockaddr*)&broadcastAddr, sizeof(broadcastAddr)) == SOCKET_ERROR) {
        printf("Broadcast bind error\n");
        closesocket(tcpSocket);       
        closesocket(udpSocket);       
        closesocket(broadcastSocket); 
        WSACleanup();                 
        return 1;                     
    }

    printf("[INFO] All sockets created and bound\n");

    thread udpThread(HandleUdp, udpSocket);

    thread broadcastThread(HandleBroadcast, broadcastSocket);

    udpThread.detach();
    broadcastThread.detach();

    printf("[INFO] Server is running. Waiting for connections...\n\n");


    while (true) {
        SOCKET clientSocket = accept(tcpSocket, NULL, NULL);

        if (clientSocket != INVALID_SOCKET) {
            thread clientThread(HandleTcpClient, clientSocket);
            clientThread.detach();  
        }

    }

    closesocket(tcpSocket);
    closesocket(udpSocket);
    closesocket(broadcastSocket);

    WSACleanup();

    return 0;
}